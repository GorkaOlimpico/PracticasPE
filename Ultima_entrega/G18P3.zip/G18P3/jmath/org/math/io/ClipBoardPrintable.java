package org.math.io;

/**
 * BSD License
 * 
 * @author Yann RICHET
 */

public interface ClipBoardPrintable {
    public void toClipBoard();
}